import React, { useRef, useState } from 'react';
import {
  PLANETS,
  MAC_CORPUS_AND_ENGINE_VIEWS,
  REFLEX_ARCHITECTURES,
  INITIAL_AWARD_CERTIFICATES,
  PUBLICATION_AND_HONOR_PROOFS,
  AwardCertificateItem,
  PlanetId,
  StudioModelId,
} from '../data/portfolioData';

interface ArchiveInteractiveOverlayProps {
  worldMode: 'intro' | 'white-space';
  focusedPlanetId: PlanetId;
  activeStudioModelId: StudioModelId;
  isLoadingModel: boolean;
  macViewIndex: number;
  reflexArchIndex: number;
  slicingEnabled: boolean;
  phonePresetIndex: number;
  hasCustomScreenshot: boolean;
  onSelectPlanetInIntro: (planetId: PlanetId) => void;
  onEnterWhiteSpace: (planetId: PlanetId) => void;
  onReturnToIntro: () => void;
  onSelectStudioModel: (modelId: StudioModelId) => void;
  onChangeMacView: (idx: number) => void;
  onChangeReflexArch: (idx: number) => void;
  onToggleSlicing: () => void;
  onChangePhonePreset: (idx: number) => void;
  onUploadPhoneScreenshot: (file: File) => void;
  onClearPhoneScreenshot: () => void;
  customRelicNames?: Partial<Record<'dragon-relic' | 'lantern-relic', string>>;
  onUploadRelicModel?: (
    slotId: 'dragon-relic' | 'lantern-relic',
    files: FileList
  ) => void;
}

export const ArchiveInteractiveOverlay: React.FC<
  ArchiveInteractiveOverlayProps
> = ({
  worldMode,
  focusedPlanetId,
  activeStudioModelId,
  isLoadingModel,
  macViewIndex,
  reflexArchIndex,
  slicingEnabled,
  phonePresetIndex,
  hasCustomScreenshot,
  onSelectPlanetInIntro,
  onEnterWhiteSpace,
  onReturnToIntro,
  onSelectStudioModel,
  onChangeMacView,
  onChangeReflexArch,
  onToggleSlicing,
  onChangePhonePreset,
  onUploadPhoneScreenshot,
  onClearPhoneScreenshot,
  customRelicNames,
  onUploadRelicModel,
}) => {
  const phoneFileInputRef = useRef<HTMLInputElement | null>(null);
  const certUploadInputRef = useRef<HTMLInputElement | null>(null);
  const relicSlot1InputRef = useRef<HTMLInputElement | null>(null);
  const relicSlot2InputRef = useRef<HTMLInputElement | null>(null);

  const [certificates, setCertificates] = useState<AwardCertificateItem[]>(
    INITIAL_AWARD_CERTIFICATES
  );
  const [lightboxCert, setLightboxCert] =
    useState<AwardCertificateItem | null>(null);

  const currentPlanet =
    PLANETS.find((p) => p.id === focusedPlanetId) || PLANETS[0];
  const currentPlanetIndex = PLANETS.findIndex((p) => p.id === focusedPlanetId);

  const currentArtifact =
    currentPlanet.studioArtifacts.find((a) => a.id === activeStudioModelId) ||
    currentPlanet.studioArtifacts[0];

  const handlePrevPlanet = () => {
    const prevIdx = (currentPlanetIndex - 1 + PLANETS.length) % PLANETS.length;
    onSelectPlanetInIntro(PLANETS[prevIdx].id);
  };

  const handleNextPlanet = () => {
    const nextIdx = (currentPlanetIndex + 1) % PLANETS.length;
    onSelectPlanetInIntro(PLANETS[nextIdx].id);
  };

  const handleUploadMoreCertificates = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const added: AwardCertificateItem[] = [];
    Array.from(files).forEach((file, idx) => {
      const url = URL.createObjectURL(file);
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      added.push({
        id: `custom-cert-${Date.now()}-${idx}`,
        title: cleanName,
        awardLevel: '实证奖状原件',
        projectTitle: '新增上传获奖证书 / 实证扫描件',
        roleLine: '殷添行 作品集实证档案',
        issuer: '官方颁发证书原件',
        certNo: 'VERIFIED',
        date: '2025–2026',
        imageUrl: url,
      });
    });
    setCertificates((prev) => [...prev, ...added]);
  };

  /* =========================================================================
     WORLD 1: COSMIC INTRO (MINIMALIST PLANETARY SWITCHER — ZERO DUPLICATE CONSOLES)
     ========================================================================= */
  if (worldMode === 'intro') {
    return (
      <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-end items-center px-6 pb-14">
        <div className="text-center max-w-2xl pointer-events-auto space-y-3">
          <div className="flex items-center justify-center gap-6 text-xs tracking-[0.2em] text-slate-400 spatial-text-glow">
            <button
              type="button"
              onClick={handlePrevPlanet}
              className="hover:text-white transition-colors cursor-pointer px-2 py-1"
              aria-label="上一个星球"
            >
              ← PREV
            </button>
            <span style={{ color: currentPlanet.colorHex }}>
              {currentPlanet.index} / 04 · {currentPlanet.englishName}
            </span>
            <button
              type="button"
              onClick={handleNextPlanet}
              className="hover:text-white transition-colors cursor-pointer px-2 py-1"
              aria-label="下一个星球"
            >
              NEXT →
            </button>
          </div>

          <h1
            onClick={() => onEnterWhiteSpace(currentPlanet.id)}
            className="font-display text-4xl md:text-6xl font-extrabold text-white tracking-tight spatial-title-glow cursor-pointer hover:text-sky-300 transition-colors"
          >
            {currentPlanet.name}
          </h1>

          <p className="text-xs md:text-sm text-slate-300 spatial-text-glow">
            {currentPlanet.introSubtitle}
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => onEnterWhiteSpace(currentPlanet.id)}
              className="text-xs md:text-sm font-semibold text-sky-400 hover:text-sky-300 underline underline-offset-8 decoration-sky-400/70 transition-colors cursor-pointer spatial-text-glow"
            >
              点击进入展厅 · ENTER SPACE ↗
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* =========================================================================
     WORLD 2A: SPACE 04 — STATIC AWARDS & PUBLICATIONS EXHIBITION GALLERY (NO 3D MODEL)
     ========================================================================= */
  if (currentPlanet.isStaticGallery || focusedPlanetId === 'awards') {
    return (
      <div className="fixed inset-0 z-10 pointer-events-auto overflow-y-auto no-scrollbar px-6 md:px-14 lg:px-20 pt-24 pb-16 text-slate-900">
        <div className="max-w-[1380px] mx-auto space-y-12">
          {/* Top Gallery Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-xs tracking-widest text-slate-400">
                <button
                  type="button"
                  onClick={onReturnToIntro}
                  className="text-slate-900 font-semibold hover:text-sky-600 underline underline-offset-4 cursor-pointer"
                >
                  ← 返回星际导航
                </button>
                <span>/</span>
                <span>04 · VERIFIED AWARDS & PUBLICATIONS</span>
              </div>
              <h1 className="font-display text-2xl md:text-4xl font-extrabold text-slate-950 tracking-tight">
                国家级竞赛奖状与核心期刊论文陈列
              </h1>
            </div>

            <div>
              <input
                ref={certUploadInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => handleUploadMoreCertificates(e.target.files)}
              />
              <button
                type="button"
                onClick={() => certUploadInputRef.current?.click()}
                className="text-xs font-semibold tracking-wider text-sky-600 hover:text-sky-700 underline underline-offset-8 cursor-pointer"
              >
                + 批量投递更多奖状原件 ({certificates.length} 份在展)
              </button>
            </div>
          </div>

          {/* Certificate Image Grid (Static Museum Display) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 items-start">
            {certificates.map((cert) => (
              <div
                key={cert.id}
                onClick={() => setLightboxCert(cert)}
                className="group cursor-pointer space-y-3"
              >
                <div className="w-full aspect-[3/4] overflow-hidden bg-white shadow-[0_14px_38px_rgba(15,23,42,0.07)] flex items-center justify-center p-2 transition-transform duration-300 group-hover:-translate-y-1">
                  <img
                    src={cert.imageUrl}
                    alt={cert.title}
                    className="w-full h-full object-contain"
                    loading="lazy"
                  />
                </div>
                <div className="space-y-1 pt-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-xs font-semibold text-amber-600">
                      {cert.awardLevel}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono-tabular">
                      NO. {cert.certNo}
                    </span>
                  </div>
                  <h2 className="text-sm font-bold text-slate-900 leading-snug group-hover:text-sky-600 transition-colors">
                    {cert.title}
                  </h2>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {cert.projectTitle}
                  </p>
                  <p className="text-[11px] text-slate-400">{cert.roleLine}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Academic Paper & Official Adoption Proofs */}
          <div className="pt-4 space-y-5">
            <div className="text-xs tracking-[0.18em] text-slate-400">
              ACADEMIC PUBLICATIONS & OFFICIAL ADOPTION · 论文发表与省级批示实证
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {PUBLICATION_AND_HONOR_PROOFS.map((pub) => (
                <div key={pub.id} className="space-y-1.5">
                  <div className="text-xs font-semibold text-sky-600">
                    {pub.typeTag}
                  </div>
                  <h3 className="text-sm font-bold text-slate-950 leading-snug">
                    {pub.title}
                  </h3>
                  <p className="text-xs text-slate-600">{pub.venue}</p>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {pub.highlight}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Empirical Corpus Thesis Section (Scrollable inside Space 04 Core Papers) */}
          <div className="pt-8 border-t border-slate-200/80 space-y-6">
            <div className="space-y-2">
              <div className="text-xs font-semibold tracking-[0.18em] text-sky-600">
                EMPIRICAL LINGUISTICS & CORPUS THESIS · 核心论文与跨语境语料实证研究
              </div>
              <h2 className="font-display text-xl md:text-3xl font-extrabold text-slate-950 tracking-tight">
                十年 6,386 篇外媒涉华语料实证：表层词典极性与深层语用意图背离研究
              </h2>
              <p className="text-xs md:text-sm text-slate-500 leading-relaxed max-w-4xl">
                基于十年跨度（6,386 篇）涉华英文新闻报道构建大规模语料库，采用 BERTopic 动态主题演化建模，系统对比传统情感词典（VADER）与大语言模型深层语境标注（Claude）在外交让步、转折与反讽语境下的显著背离。
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="space-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono-tabular text-2xl md:text-3xl font-bold text-slate-950">
                    r = 0.348
                  </span>
                  <span className="text-xs font-semibold text-sky-600">
                    相关系数
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  VADER 表层词典极性与 Claude 语境标注显著背离
                </p>
              </div>
              <div className="space-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono-tabular text-2xl md:text-3xl font-bold text-slate-950">
                    6,386
                  </span>
                  <span className="text-xs font-semibold text-sky-600">
                    篇 (10年)
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  十年跨度外媒涉华英文报道自建实证语料库
                </p>
              </div>
              <div className="space-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono-tabular text-2xl md:text-3xl font-bold text-slate-950">
                    p &lt; 0.001
                  </span>
                  <span className="text-xs font-semibold text-sky-600">
                    显著性
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  跨语境极性背离具备高度统计学显著性
                </p>
              </div>
              <div className="space-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono-tabular text-2xl md:text-3xl font-bold text-slate-950">
                    BERTopic
                  </span>
                  <span className="text-xs font-semibold text-sky-600">
                    主题建模
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  经贸供应链、科技半导体、绿色转型多维演化追踪
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-2">
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-900">
                  01 / 核心实证发现：词典极性 (Lexicon) ≠ 真实语用意图 (Pragmatics)
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  外交与政经报道大量使用「先扬后抑」让步转折句式（如 &ldquo;While Beijing touts green transition milestones, structural headwinds remain...&rdquo;）。传统 VADER 词典受表层积极词汇触发误判为正向（+0.42），而深层语境模型准确捕获转折后的消极叙事框架（-0.38）。
                </p>
              </div>
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-900">
                  02 / 学理到工程的桥梁：驱动端侧语义意图路由研究
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  该论文实证结论直接揭示了「浅层关键词/词典规则无法胜任复杂真实语境意图识别」，从而在学理上驱动了后续基于轻量化预训练模型（Qwen3-0.6B）与动态子词表切片（Dynamic Sub-Vocab Slicing）的端侧意图路由引擎研发。
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Screen Certificate Lightbox Modal */}
        {lightboxCert && (
          <div
            onClick={() => setLightboxCert(null)}
            className="fixed inset-0 z-50 bg-slate-950/85 flex flex-col items-center justify-center p-6 md:p-12 cursor-zoom-out"
          >
            <img
              src={lightboxCert.imageUrl}
              alt={lightboxCert.title}
              className="max-w-full max-h-[80vh] object-contain shadow-2xl"
            />
            <div className="mt-4 text-center text-white space-y-1">
              <div className="text-sm md:text-base font-bold">
                {lightboxCert.title} · {lightboxCert.awardLevel}
              </div>
              <div className="text-xs text-slate-300">
                {lightboxCert.projectTitle} | 证书编号：{lightboxCert.certNo}（点击任意处关闭）
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  /* =========================================================================
     WORLD 2B: SPACES 01, 02, 03 — 3D WORK & EMPIRICAL PROOF EXHIBITION HALLS
     ========================================================================= */
  if (!currentArtifact) return null;

  const isComputerModel =
    currentArtifact.id === 'all-in-one-mac' ||
    currentArtifact.id === 'retro-laptop';

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-center px-6 md:px-12 lg:px-16 pt-20 pb-12 text-slate-900">
      {isLoadingModel && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 text-xs tracking-widest text-slate-500">
          正在载入真实 3D 模型 (.GLB)...
        </div>
      )}

      <div className="w-full max-w-[1420px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* LEFT FLANK: Concise Work Identity & Real GLB Model Switcher */}
        <div className="lg:col-span-4 pointer-events-auto space-y-5 max-h-[78vh] overflow-y-auto no-scrollbar pr-2">
          <div className="flex items-center gap-2.5 text-xs tracking-widest text-slate-400">
            <button
              type="button"
              onClick={onReturnToIntro}
              className="text-slate-900 font-semibold hover:text-sky-600 underline underline-offset-4 cursor-pointer"
            >
              ← 返回星际导航
            </button>
            <span>/</span>
            <span>SPACE {currentPlanet.index}</span>
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-semibold tracking-[0.14em] text-sky-600">
              {currentArtifact.categoryTag}
            </div>
            <h1 className="font-display text-2xl md:text-4xl font-extrabold text-slate-950 tracking-tight leading-tight">
              {currentArtifact.projectTitle}
            </h1>
            <p className="text-xs text-slate-500 leading-relaxed">
              {currentArtifact.projectSubtitle}
            </p>
          </div>

          {/* Concise Verifiable Proof Lines */}
          <div className="space-y-2.5 pt-1">
            {currentArtifact.proofPoints.map((pt, idx) => (
              <p
                key={idx}
                className="text-xs md:text-sm text-slate-600 leading-relaxed"
              >
                <span className="font-bold text-slate-900 mr-2 font-mono-tabular">
                  0{idx + 1} /
                </span>
                {pt}
              </p>
            ))}
          </div>

          {currentArtifact.externalLink && (
            <div className="pt-1">
              <a
                href={currentArtifact.externalLink.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold tracking-wider text-sky-600 hover:text-sky-700 underline underline-offset-8"
              >
                {currentArtifact.externalLink.label}
              </a>
            </div>
          )}

          {/* Prominent 3D Model / Project Switcher Buttons */}
          {currentPlanet.studioArtifacts.length > 1 && (
            <div className="pt-4 space-y-2.5">
              <div className="text-xs font-bold tracking-wider text-slate-700 uppercase">
                切换当前展厅 3D 模型 / 核心项目 ({currentPlanet.studioArtifacts.length} 项)：
              </div>
              <div className="flex flex-col gap-2.5">
                {currentPlanet.studioArtifacts.map((art, i) => {
                  const active = art.id === currentArtifact.id;
                  const customName =
                    art.id === 'dragon-relic' || art.id === 'lantern-relic'
                      ? customRelicNames?.[art.id]
                      : undefined;
                  return (
                    <button
                      key={art.id}
                      type="button"
                      onClick={() => onSelectStudioModel(art.id)}
                      className={`w-full text-left px-4 py-3 text-sm font-bold border-2 transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        active
                          ? 'bg-slate-950 text-white border-slate-950 shadow-[0_10px_24px_rgba(15,23,42,0.16)]'
                          : 'bg-white/90 text-slate-800 border-slate-300 hover:border-slate-950 hover:text-slate-950 hover:bg-white'
                      }`}
                    >
                      <span className="truncate">
                        0{i + 1}. {customName || art.name}
                      </span>
                      <span
                        className={`text-[11px] font-semibold shrink-0 ${
                          active ? 'text-sky-300' : 'text-sky-600'
                        }`}
                      >
                        {active ? '● 当前展示' : '点击切换 →'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* CENTER COLUMN: Unobstructed 3D Object Viewport */}
        <div className="hidden lg:flex lg:col-span-4 h-[60vh] flex-col justify-end items-center pointer-events-none">
          <div className="text-[11px] text-slate-400 tracking-[0.16em]">
            鼠标拖拽或滚动滚轮可自由旋转检视
          </div>
        </div>

        {/* RIGHT FLANK: Empirical Numbers & Direct Interactive Proof Controls */}
        <div className="lg:col-span-4 pointer-events-auto space-y-6 max-h-[78vh] overflow-y-auto no-scrollbar pl-2">
          {/* Quantitative Metrics */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-5">
            {currentArtifact.metrics.map((m, i) => (
              <div key={i} className="space-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono-tabular text-2xl md:text-3xl font-bold text-slate-950 tracking-tight">
                    {m.value}
                  </span>
                  <span className="text-xs font-semibold text-sky-600">
                    {m.unit}
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-snug">{m.label}</p>
              </div>
            ))}
          </div>

          {/* SPACE 02 INTERACTION A: Ion Drive -> Reflex Engine & Sub-Vocab Slicing Controls */}
          {currentArtifact.id === 'ion-drive' && (
            <div className="space-y-3.5 pt-2">
              <div className="text-xs font-bold text-slate-900">
                切换 Reflex 端侧路由架构与算子切片加速实测：
              </div>
              <div className="flex flex-wrap gap-2.5">
                {REFLEX_ARCHITECTURES.map((arch, idx) => (
                  <button
                    key={arch.id}
                    type="button"
                    onClick={() => onChangeReflexArch(idx)}
                    className={`px-3.5 py-2 text-xs font-bold border transition-all cursor-pointer ${
                      reflexArchIndex === idx
                        ? 'bg-slate-950 text-white border-slate-950'
                        : 'bg-white text-slate-700 border-slate-300 hover:border-slate-900'
                    }`}
                  >
                    {arch.name} ({arch.accuracy} · {arch.latencyMs})
                  </button>
                ))}
              </div>
              <div>
                <button
                  type="button"
                  onClick={onToggleSlicing}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-700 underline underline-offset-4 cursor-pointer"
                >
                  {slicingEnabled
                    ? '⚡ Dynamic Sub-Vocab Slicing 已开启 (0.045ms · 点击对比全词表基线)'
                    : '当前为全词表基线 (1.692ms · 点击开启算子切片加速)'}
                </button>
              </div>
            </div>
          )}

          {/* SPACE 02 INTERACTION B: Retro Laptop -> Lenovo AI PC System Voice Agent Screen Switcher */}
          {isComputerModel && (
            <div className="space-y-3.5 pt-2">
              <div className="text-xs font-bold text-slate-900">
                点击切换 PC 屏幕内的联想 AI PC 语音入口与端侧路由画面：
              </div>
              <div className="flex flex-col gap-2">
                {MAC_CORPUS_AND_ENGINE_VIEWS.slice(0, 2).map((v, idx) => {
                  const active = macViewIndex === idx;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => onChangeMacView(idx)}
                      className={`text-left px-3.5 py-2.5 text-xs font-bold border transition-all cursor-pointer ${
                        active
                          ? 'bg-sky-600 text-white border-sky-600'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-slate-900'
                      }`}
                    >
                      {v.tabLabel}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* SPACE 03 INTERACTION A: Real SONY A7R3 Camera */}
          {currentArtifact.id === 'dslr-camera' && (
            <div className="space-y-3 pt-2">
              <div className="text-xs text-slate-600 leading-relaxed">
                拖拽旋转中央真实 SONY A7R3 + FE 16-35mm F2.8 GM 模型检视细节，或点击下方按钮切换至 iPhone 18 Pro Max 商业产品场景。
              </div>
            </div>
          )}

          {/* SPACE 03 INTERACTION B: Real iPhone GLB Screenshot Upload */}
          {currentArtifact.id === 'iphone-real' && (
            <div className="space-y-3 pt-2">
              <div className="flex flex-wrap items-center gap-5">
                <input
                  ref={phoneFileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) onUploadPhoneScreenshot(file);
                  }}
                />
                <button
                  type="button"
                  onClick={() => phoneFileInputRef.current?.click()}
                  className="text-xs font-bold text-sky-600 hover:text-sky-700 underline underline-offset-4 cursor-pointer"
                >
                  📱 上传真实手机截图贴入 iPhone 屏幕 ↗
                </button>
                {hasCustomScreenshot && (
                  <button
                    type="button"
                    onClick={onClearPhoneScreenshot}
                    className="text-xs text-slate-500 hover:text-slate-900 underline underline-offset-4 cursor-pointer"
                  >
                    恢复默认 Flower 预览
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Quick Jump to Space 04 Certificates */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => onEnterWhiteSpace('awards')}
              className="text-xs font-semibold text-slate-600 hover:text-slate-950 underline underline-offset-8 cursor-pointer"
            >
              检视挑战杯 / 国创赛获奖证书与核心期刊论文原件 →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
