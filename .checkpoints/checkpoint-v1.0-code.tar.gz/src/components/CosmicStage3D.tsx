import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { PLANETS, PlanetId, StudioModelId } from '../data/portfolioData';
import {
  createStudioContactShadowTexture,
  createCleanSaturnRingTexture,
  createCameraPbrMaps,
  drawSonyCameraLcdCanvas,
  drawRetroMacTerminalCanvas,
  drawSmartphoneScreenCanvas,
} from '../three/proceduralTextures';

const sRGBEncoding: THREE.ColorSpace =
  ((THREE as Record<string, unknown>).sRGBEncoding as THREE.ColorSpace) ||
  THREE.SRGBColorSpace;

// Pre-allocated math helpers at module scope (Zero GC in render loop)
const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(0, 0, 0);
const _dummy = new THREE.Object3D();
const _mouse = new THREE.Vector2();
const _darkBgColor = new THREE.Color(0x04060a);
const _whiteStudioColor = new THREE.Color(0xf8fafc);
const _lerpBgColor = new THREE.Color(0x04060a);

export interface CosmicStageProps {
  worldMode: 'intro' | 'white-space';
  scrollProgress: number;
  focusedPlanetId: PlanetId;
  activeStudioModelId: StudioModelId;
  macViewIndex: number;
  reflexArchIndex: number;
  slicingEnabled: boolean;
  phonePresetIndex: number;
  customPhoneImage: HTMLImageElement | null;
  customRelicUpload?: {
    slotId: 'dragon-relic' | 'lantern-relic';
    files: File[];
    timestamp: number;
  } | null;
  onFocusPlanetInIntro: (planetId: PlanetId) => void;
  onEnterWhiteSpace: (planetId: PlanetId) => void;
  onModelLoadStateChange?: (loading: boolean) => void;
  onRelicSaved?: (
    slotId: 'dragon-relic' | 'lantern-relic',
    displayName: string,
    savedToServer: boolean
  ) => void;
}

/**
 * Builds a clean radial RingGeometry mapped 0..1 along radius for the single-band Saturn ring texture.
 */
function createRadialRingGeometry(
  innerRadius: number,
  outerRadius: number
): THREE.RingGeometry {
  const geo = new THREE.RingGeometry(innerRadius, outerRadius, 128);
  const pos = geo.attributes.position;
  const uv = geo.attributes.uv;
  const v3 = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v3.fromBufferAttribute(pos, i);
    const radius = v3.length();
    const u = THREE.MathUtils.clamp(
      (radius - innerRadius) / (outerRadius - innerRadius),
      0,
      1
    );
    uv.setXY(i, u, 0.5);
  }
  return geo;
}

export const CosmicStage3D: React.FC<CosmicStageProps> = ({
  worldMode,
  scrollProgress,
  focusedPlanetId,
  activeStudioModelId,
  macViewIndex,
  reflexArchIndex,
  slicingEnabled,
  phonePresetIndex,
  customPhoneImage,
  customRelicUpload,
  onFocusPlanetInIntro,
  onEnterWhiteSpace,
  onModelLoadStateChange,
  onRelicSaved,
}) => {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const stateRef = useRef({
    worldMode,
    scrollProgress,
    focusedPlanetId,
    activeStudioModelId,
    macViewIndex,
    reflexArchIndex,
    slicingEnabled,
    phonePresetIndex,
    customPhoneImage,
    warpBoost: 0,
    whiteBlend: worldMode === 'white-space' ? 1 : 0,
    userRotX: 0,
    userRotY: 0,
  });

  useEffect(() => {
    const prevWorld = stateRef.current.worldMode;
    const prevPlanet = stateRef.current.focusedPlanetId;
    const prevModel = stateRef.current.activeStudioModelId;

    if (prevWorld !== worldMode || prevPlanet !== focusedPlanetId) {
      stateRef.current.warpBoost = 1.0;
      stateRef.current.userRotX = 0;
      stateRef.current.userRotY = 0;
    } else if (prevModel !== activeStudioModelId) {
      stateRef.current.userRotX = 0;
      stateRef.current.userRotY = 0;
    }

    stateRef.current.worldMode = worldMode;
    stateRef.current.scrollProgress = scrollProgress;
    stateRef.current.focusedPlanetId = focusedPlanetId;
    stateRef.current.activeStudioModelId = activeStudioModelId;
    stateRef.current.macViewIndex = macViewIndex;
    stateRef.current.reflexArchIndex = reflexArchIndex;
    stateRef.current.slicingEnabled = slicingEnabled;
    stateRef.current.phonePresetIndex = phonePresetIndex;
    stateRef.current.customPhoneImage = customPhoneImage;
  }, [
    worldMode,
    scrollProgress,
    focusedPlanetId,
    activeStudioModelId,
    macViewIndex,
    reflexArchIndex,
    slicingEnabled,
    phonePresetIndex,
    customPhoneImage,
  ]);

  const callbacksRef = useRef({
    onFocusPlanetInIntro,
    onEnterWhiteSpace,
    onModelLoadStateChange,
    onRelicSaved,
  });
  useEffect(() => {
    callbacksRef.current = {
      onFocusPlanetInIntro,
      onEnterWhiteSpace,
      onModelLoadStateChange,
      onRelicSaved,
    };
  }, [
    onFocusPlanetInIntro,
    onEnterWhiteSpace,
    onModelLoadStateChange,
    onRelicSaved,
  ]);

  const loadStudioModelFnRef = useRef<((modelId: StudioModelId) => void) | null>(
    null
  );
  const uploadRelicFilesFnRef = useRef<
    | ((
        slotId: 'dragon-relic' | 'lantern-relic',
        files: File[]
      ) => Promise<void>)
    | null
  >(null);

  useEffect(() => {
    if (loadStudioModelFnRef.current) {
      loadStudioModelFnRef.current(activeStudioModelId);
    }
  }, [activeStudioModelId]);

  useEffect(() => {
    if (customRelicUpload && uploadRelicFilesFnRef.current) {
      uploadRelicFilesFnRef.current(
        customRelicUpload.slotId,
        customRelicUpload.files
      );
    }
  }, [customRelicUpload]);

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    const isHeadless =
      navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent);

    // 1. Initialize Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x04060a);
    const sceneFog = new THREE.FogExp2(0x04060a, 0.012);
    scene.fog = sceneFog;

    const camera = new THREE.PerspectiveCamera(
      42,
      window.innerWidth / window.innerHeight,
      0.1,
      300
    );
    camera.position.set(-14, 1.8, -4.5);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isHeadless,
        powerPreference: 'high-performance',
      });
    } catch {
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(
      isHeadless ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = !isHeadless;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 2. Studio Environment Map
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    pmremGenerator.dispose();

    // 3. Clean 3-Point Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 0.95);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 2.3);
    keyLight.position.set(10, 14, 14);
    keyLight.castShadow = !isHeadless;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xe2e8f0, 0.9);
    fillLight.position.set(-12, 4, 10);
    scene.add(fillLight);

    // =========================================================================
    // WORLD 1 GROUP: COSMIC INTRO (4 Distinct Solar System Planets, Refined Scale)
    // =========================================================================
    const cosmicIntroGroup = new THREE.Group();
    scene.add(cosmicIntroGroup);

    const starCount = 1100;
    const starGeo = new THREE.SphereGeometry(0.048, 6, 6);
    const starMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.82,
    });
    const starInstanced = new THREE.InstancedMesh(starGeo, starMat, starCount);
    starInstanced.frustumCulled = false;

    const starCoords = new Float32Array(starCount * 3);
    const starPalette = [
      new THREE.Color(0xf8fafc),
      new THREE.Color(0xe2e8f0),
      new THREE.Color(0xfef08a),
      new THREE.Color(0xbae6fd),
    ];

    for (let i = 0; i < starCount; i++) {
      const sx = (Math.random() - 0.5) * 140;
      const sy = (Math.random() - 0.5) * 90;
      const sz = 20 - Math.random() * 110;
      starCoords[i * 3] = sx;
      starCoords[i * 3 + 1] = sy;
      starCoords[i * 3 + 2] = sz;

      _dummy.position.set(sx, sy, sz);
      _dummy.scale.setScalar(0.45 + Math.random() * 1.0);
      _dummy.updateMatrix();
      starInstanced.setMatrixAt(i, _dummy.matrix);
      starInstanced.setColorAt(i, starPalette[i % starPalette.length]);
    }
    starInstanced.instanceMatrix.needsUpdate = true;
    if (starInstanced.instanceColor) starInstanced.instanceColor.needsUpdate = true;
    starInstanced.computeBoundingSphere();
    cosmicIntroGroup.add(starInstanced);

    const texLoader = new THREE.TextureLoader();
    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    const loadSRGBTex = (path: string) =>
      texLoader.load(path, (t) => {
        t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = maxAnisotropy;
      });

    const marsTex = loadSRGBTex('/textures/mars.jpg');
    const jupiterTex = loadSRGBTex('/textures/jupiter.jpg');
    const saturnTex = loadSRGBTex('/textures/saturn.jpg');
    const cleanSaturnRingTex = createCleanSaturnRingTexture();
    const earthTex = loadSRGBTex('/textures/earth_atmos.jpg');
    const earthNormal = texLoader.load('/textures/earth_normal.jpg');
    const moonTex = loadSRGBTex('/textures/moon.jpg');

    const planetClickMeshes: THREE.Object3D[] = [];
    const planetGroupsMap = new Map<PlanetId, THREE.Group>();

    PLANETS.forEach((pData, idx) => {
      const pGroup = new THREE.Group();
      pGroup.position.set(...pData.position);
      pGroup.userData = {
        type: 'planet',
        planetId: pData.id,
      };

      const sphereGeo = new THREE.SphereGeometry(pData.radius, 64, 64);
      let sphereMat: THREE.MeshStandardMaterial;

      if (idx === 0) {
        sphereMat = new THREE.MeshStandardMaterial({
          map: marsTex,
          roughness: 0.82,
          metalness: 0.05,
        });
      } else if (idx === 1) {
        sphereMat = new THREE.MeshStandardMaterial({
          map: jupiterTex,
          roughness: 0.65,
          metalness: 0.05,
        });
      } else if (idx === 2) {
        sphereMat = new THREE.MeshStandardMaterial({
          map: saturnTex,
          roughness: 0.7,
          metalness: 0.05,
        });

        const ringGeo = createRadialRingGeometry(
          pData.radius * 1.36,
          pData.radius * 2.15
        );
        const ringMat = new THREE.MeshStandardMaterial({
          map: cleanSaturnRingTex,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.9,
          roughness: 0.6,
          depthWrite: false,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2.25;
        ringMesh.rotation.y = -0.2;
        pGroup.add(ringMesh);
      } else {
        sphereMat = new THREE.MeshStandardMaterial({
          map: earthTex,
          normalMap: earthNormal,
          normalScale: new THREE.Vector2(1.1, 1.1),
          roughness: 0.55,
          metalness: 0.1,
        });

        const moonGeo = new THREE.SphereGeometry(pData.radius * 0.23, 32, 32);
        const moonMat = new THREE.MeshStandardMaterial({
          map: moonTex,
          roughness: 0.88,
        });
        const moonMesh = new THREE.Mesh(moonGeo, moonMat);
        moonMesh.position.set(pData.radius * 1.85, 0.35, 0);
        pGroup.add(moonMesh);
      }

      const sphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
      sphereMesh.rotation.z = 0.1 * (idx % 2 === 0 ? 1 : -1);
      sphereMesh.userData = pGroup.userData;
      pGroup.add(sphereMesh);
      planetClickMeshes.push(sphereMesh);

      cosmicIntroGroup.add(pGroup);
      planetGroupsMap.set(pData.id, pGroup);
    });

    // =========================================================================
    // WORLD 2 GROUP: PURE WHITE STUDIO SPACE (100% Real Downloaded .GLB Models)
    // =========================================================================
    const whiteStudioGroup = new THREE.Group();
    whiteStudioGroup.position.set(0, 0, 0);
    whiteStudioGroup.visible = false;
    scene.add(whiteStudioGroup);

    const shadowTex = createStudioContactShadowTexture();
    const shadowGeo = new THREE.PlaneGeometry(4.4, 4.4);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.78,
    });
    const contactShadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    contactShadowMesh.position.set(0, -1.35, 0);
    whiteStudioGroup.add(contactShadowMesh);

    const centerModelHolder = new THREE.Group();
    centerModelHolder.position.set(0, 0, 0);
    whiteStudioGroup.add(centerModelHolder);

    // Dynamic Screen Textures mapped onto the real downloaded GLB models
    const crtCanvas = document.createElement('canvas');
    crtCanvas.width = 768;
    crtCanvas.height = 512;
    const crtTexture = new THREE.CanvasTexture(crtCanvas);
    crtTexture.colorSpace = THREE.SRGBColorSpace;
    crtTexture.anisotropy = maxAnisotropy;

    const cameraLcdCanvas = document.createElement('canvas');
    cameraLcdCanvas.width = 640;
    cameraLcdCanvas.height = 420;
    const cameraLcdTexture = new THREE.CanvasTexture(cameraLcdCanvas);
    cameraLcdTexture.colorSpace = sRGBEncoding;
    cameraLcdTexture.anisotropy = maxAnisotropy;

    const cameraPbrMaps = createCameraPbrMaps(maxAnisotropy);

    const phoneCanvas = document.createElement('canvas');
    phoneCanvas.width = 512;
    phoneCanvas.height = 1024;
    const phoneTexture = new THREE.CanvasTexture(phoneCanvas);
    phoneTexture.colorSpace = sRGBEncoding;
    phoneTexture.anisotropy = maxAnisotropy;

    const dracoLoader = new DRACOLoader();
    const basePrefix = (import.meta.env?.BASE_URL || '/').replace(/\/$/, '');
    dracoLoader.setDecoderPath(`${basePrefix}/draco/`);
    const gltfLoader = new GLTFLoader();
    gltfLoader.setDRACOLoader(dracoLoader);

    const glbCache = new Map<
      string,
      {
        wrapper: THREE.Group;
        rawRoot: THREE.Object3D;
        animations: THREE.AnimationClip[];
      }
    >();
    const pendingLoads = new Map<
      string,
      Array<
        (cached: {
          wrapper: THREE.Group;
          rawRoot: THREE.Object3D;
          animations: THREE.AnimationClip[];
        }) => void
      >
    >();
    let activeMixer: THREE.AnimationMixer | null = null;
    let currentLoadToken = 0;

    /**
     * Ensures the camera model's materials in the loader function follow the PBR
     * metallic/roughness workflow with proper map channels (map, normalMap,
     * roughnessMap, metalnessMap) and sets base color map colorSpace to sRGBEncoding.
     */
    const updateCameraModelMaterials = (
      root: THREE.Object3D,
      modelId: StudioModelId
    ) => {
      const isCameraModel =
        modelId === 'dslr-camera' || modelId === 'compact-camera';

      root.traverse((child) => {
        if (!(child as THREE.Mesh).isMesh) return;
        const mesh = child as THREE.Mesh;
        mesh.castShadow = !isHeadless && modelId !== 'dslr-camera';
        mesh.receiveShadow = !isHeadless && modelId !== 'dslr-camera';

        const applyPbrWorkflow = (
          mat: THREE.Material
        ): THREE.MeshStandardMaterial => {
          const srcMat = mat as THREE.MeshStandardMaterial;
          const pbrMat = srcMat.isMeshStandardMaterial
            ? srcMat
            : new THREE.MeshStandardMaterial({
                name: mat.name,
                color:
                  (mat as THREE.MeshBasicMaterial).color?.clone() ??
                  new THREE.Color(0xffffff),
              });

          const map = pbrMat.map || (isCameraModel ? cameraPbrMaps.map : null);
          const normalMap =
            pbrMat.normalMap ||
            (isCameraModel ? cameraPbrMaps.normalMap : null);
          const roughnessMap =
            pbrMat.roughnessMap ||
            pbrMat.metalnessMap ||
            (isCameraModel ? cameraPbrMaps.roughnessMap : null);
          const metalnessMap =
            pbrMat.metalnessMap ||
            pbrMat.roughnessMap ||
            (isCameraModel ? cameraPbrMaps.metalnessMap : null);

          pbrMat.map = map;
          pbrMat.normalMap = normalMap;
          pbrMat.roughnessMap = roughnessMap;
          pbrMat.metalnessMap = metalnessMap;

          if (pbrMat.map) {
            pbrMat.map.colorSpace = sRGBEncoding;
            pbrMat.map.anisotropy = maxAnisotropy;
            pbrMat.map.needsUpdate = true;
            renderer.initTexture(pbrMat.map);
          }
          if (pbrMat.normalMap) {
            pbrMat.normalMap.colorSpace = THREE.NoColorSpace;
            pbrMat.normalMap.anisotropy = maxAnisotropy;
            if (isCameraModel) {
              pbrMat.normalScale = new THREE.Vector2(0.04, 0.04);
            }
            pbrMat.normalMap.needsUpdate = true;
          }
          if (pbrMat.roughnessMap) {
            pbrMat.roughnessMap.colorSpace = THREE.NoColorSpace;
            pbrMat.roughnessMap.anisotropy = maxAnisotropy;
            pbrMat.roughnessMap.needsUpdate = true;
          }
          if (pbrMat.metalnessMap) {
            pbrMat.metalnessMap.colorSpace = THREE.NoColorSpace;
            pbrMat.metalnessMap.anisotropy = maxAnisotropy;
            pbrMat.metalnessMap.needsUpdate = true;
          }

          if (isCameraModel) {
            pbrMat.roughness = THREE.MathUtils.clamp(
              pbrMat.roughness ?? 0.42,
              0.12,
              0.85
            );
            pbrMat.metalness = THREE.MathUtils.clamp(
              pbrMat.metalness ?? 0.15,
              0.08,
              0.85
            );
            pbrMat.envMapIntensity = 1.15;
          } else if (modelId === 'dragon-relic') {
            pbrMat.roughness = 0.28;
            pbrMat.metalness = 0.25;
            pbrMat.envMapIntensity = 1.25;
          } else if (modelId === 'lantern-relic') {
            pbrMat.roughness = 0.35;
            pbrMat.metalness = 0.12;
            pbrMat.envMapIntensity = 1.25;
          }

          pbrMat.needsUpdate = true;
          return pbrMat;
        };

        if (Array.isArray(mesh.material)) {
          mesh.material = mesh.material.map(applyPbrWorkflow);
        } else if (mesh.material) {
          mesh.material = applyPbrWorkflow(mesh.material);
        }
      });
    };

    /**
     * Attaches live interactive CanvasTextures onto the screen nodes inside the
     * real downloaded .GLB models (All-in-One Mac, Retro Laptop, DSLR Camera, iPhone).
     */
    const attachDynamicScreenToRealGlb = (
      root: THREE.Object3D,
      modelId: StudioModelId
    ) => {
      if (modelId === 'all-in-one-mac') {
        const displayGlass = root.getObjectByName('Display glass');
        if (displayGlass) {
          const screenPlane = new THREE.Mesh(
            new THREE.PlaneGeometry(0.478, 0.312),
            new THREE.MeshBasicMaterial({ map: crtTexture })
          );
          screenPlane.position.set(0, 0, 0.0022);
          displayGlass.add(screenPlane);
        }
      } else if (modelId === 'retro-laptop') {
        const laptopScreen = root.getObjectByName('classic_laptop_screen');
        if (laptopScreen) {
          const screenPlane = new THREE.Mesh(
            new THREE.PlaneGeometry(0.444, 0.362),
            new THREE.MeshBasicMaterial({ map: crtTexture })
          );
          screenPlane.position.set(0.0004, 0.2416, 0.0072);
          laptopScreen.add(screenPlane);
        }
      } else if (modelId === 'dslr-camera' || modelId === 'compact-camera') {
        const insetGlass = root.getObjectByName('Inset display glass');
        if (insetGlass) {
          cameraLcdTexture.colorSpace = sRGBEncoding;
          const lcdMat = new THREE.MeshStandardMaterial({
            map: cameraLcdTexture,
            normalMap: cameraPbrMaps.normalMap,
            roughnessMap: cameraPbrMaps.roughnessMap,
            metalnessMap: cameraPbrMaps.metalnessMap,
            roughness: 0.2,
            metalness: 0.1,
            emissive: new THREE.Color(0xffffff),
            emissiveMap: cameraLcdTexture,
            emissiveIntensity: 0.35,
          });
          const lcdPlane = new THREE.Mesh(
            new THREE.PlaneGeometry(0.093, 0.059),
            lcdMat
          );
          lcdPlane.rotation.y = Math.PI;
          lcdPlane.position.set(0, 0, -0.0016);
          insetGlass.add(lcdPlane);
        }
      } else if (modelId === 'iphone-real') {
        root.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const m = child as THREE.Mesh;
            const matName = (m.material as THREE.Material)?.name || '';
            if (
              child.name.includes('Front_Screen') ||
              child.name.includes('scr') ||
              matName === 'COLOUR_Cherry_Screen' ||
              matName === 'material_10'
            ) {
              m.material = new THREE.MeshBasicMaterial({
                map: phoneTexture,
              });
            }
          }
        });
      }
    };

    const buildNormalizedEntry = (
      rawRoot: THREE.Group,
      animations: THREE.AnimationClip[],
      scaleMult: number,
      initRot: [number, number, number],
      modelId: StudioModelId
    ) => {
      const wrapper = new THREE.Group();
      wrapper.add(rawRoot);

      rawRoot.updateWorldMatrix(true, true);
      const box = new THREE.Box3();
      const childBox = new THREE.Box3();
      rawRoot.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const geom = (child as THREE.Mesh).geometry;
          if (!geom.boundingBox) geom.computeBoundingBox();
          if (geom.boundingBox) {
            childBox.copy(geom.boundingBox).applyMatrix4(child.matrixWorld);
            box.union(childBox);
          }
        }
      });
      if (box.isEmpty()) {
        box.setFromObject(rawRoot);
      }

      const size = box.getSize(new THREE.Vector3());
      const center = box.getCenter(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z, 0.001);
      const normScale = (1.0 / maxDim) * scaleMult;

      rawRoot.position.sub(center);
      wrapper.scale.setScalar(normScale);
      wrapper.rotation.set(initRot[0], initRot[1], initRot[2]);

      updateCameraModelMaterials(rawRoot, modelId);
      attachDynamicScreenToRealGlb(rawRoot, modelId);

      return { wrapper, rawRoot, animations };
    };

    const mountCachedEntry = (
      entry: {
        wrapper: THREE.Group;
        rawRoot: THREE.Object3D;
        animations: THREE.AnimationClip[];
      },
      initRot: [number, number, number]
    ) => {
      while (centerModelHolder.children.length > 0) {
        centerModelHolder.remove(centerModelHolder.children[0]);
      }
      if (activeMixer) {
        activeMixer.stopAllAction();
        activeMixer = null;
      }

      entry.wrapper.rotation.set(initRot[0], initRot[1], initRot[2]);
      centerModelHolder.add(entry.wrapper);

      if (entry.animations && entry.animations.length > 0) {
        activeMixer = new THREE.AnimationMixer(entry.rawRoot);
        entry.animations.forEach((clip) => {
          activeMixer!.clipAction(clip).play();
        });
      }
    };

    const allArtifacts = PLANETS.flatMap((p) => p.studioArtifacts);

    const fetchAndCacheModel = (
      spec: (typeof allArtifacts)[number],
      onReady?: (entry: {
        wrapper: THREE.Group;
        rawRoot: THREE.Object3D;
        animations: THREE.AnimationClip[];
      }) => void,
      onError?: () => void
    ) => {
      const url = spec.modelUrl;
      if (glbCache.has(url)) {
        onReady?.(glbCache.get(url)!);
        return;
      }
      if (pendingLoads.has(url)) {
        if (onReady) pendingLoads.get(url)!.push(onReady);
        return;
      }
      pendingLoads.set(url, onReady ? [onReady] : []);

      gltfLoader.load(
        url,
        (gltf) => {
          const entry = buildNormalizedEntry(
            gltf.scene,
            gltf.animations || [],
            spec.scaleMultiplier,
            spec.initialRotation,
            spec.id
          );
          glbCache.set(url, entry);
          const waiters = pendingLoads.get(url) || [];
          pendingLoads.delete(url);
          waiters.forEach((cb) => cb(entry));
        },
        undefined,
        () => {
          pendingLoads.delete(url);
          onError?.();
        }
      );
    };

    const loadStudioModel = (modelId: StudioModelId) => {
      const token = ++currentLoadToken;
      const spec =
        allArtifacts.find((a) => a.id === modelId) || allArtifacts[0];
      if (!spec?.modelUrl) return;

      if (glbCache.has(spec.modelUrl)) {
        callbacksRef.current.onModelLoadStateChange?.(false);
        mountCachedEntry(glbCache.get(spec.modelUrl)!, spec.initialRotation);
        return;
      }

      callbacksRef.current.onModelLoadStateChange?.(true);
      fetchAndCacheModel(
        spec,
        (entry) => {
          if (token !== currentLoadToken) return;
          callbacksRef.current.onModelLoadStateChange?.(false);
          mountCachedEntry(entry, spec.initialRotation);
        },
        () => {
          if (token !== currentLoadToken) return;
          callbacksRef.current.onModelLoadStateChange?.(false);
        }
      );
    };

    const handleUploadRelicFiles = async (
      slotId: 'dragon-relic' | 'lantern-relic',
      files: File[]
    ) => {
      if (!files || files.length === 0) return;
      const spec =
        allArtifacts.find((a) => a.id === slotId) || allArtifacts[0];
      if (!spec) return;

      callbacksRef.current.onModelLoadStateChange?.(true);

      try {
        const glbFile = files.find((f) => /\.(glb|gltf)$/i.test(f.name));
        const objFile = files.find((f) => /\.(obj|txt)$/i.test(f.name));
        const mtlFile = files.find((f) => /\.mtl$/i.test(f.name));
        const imageFiles = files.filter((f) =>
          /\.(jpg|jpeg|png|webp|bmp)$/i.test(f.name)
        );

        const persistGlbBufferToServer = async (buffer: ArrayBuffer) => {
          try {
            const resp = await fetch(`/api/save-relic?slot=${slotId}`, {
              method: 'POST',
              body: buffer,
            });
            return resp.ok;
          } catch {
            return false;
          }
        };

        if (glbFile) {
          const arrayBuffer = await glbFile.arrayBuffer();
          gltfLoader.parse(
            arrayBuffer.slice(0),
            '',
            async (gltf) => {
              const entry = buildNormalizedEntry(
                gltf.scene,
                gltf.animations || [],
                spec.scaleMultiplier,
                spec.initialRotation,
                slotId
              );
              glbCache.set(spec.modelUrl, entry);
              if (stateRef.current.activeStudioModelId === slotId) {
                mountCachedEntry(entry, spec.initialRotation);
              }
              callbacksRef.current.onModelLoadStateChange?.(false);
              const saved = await persistGlbBufferToServer(arrayBuffer);
              const cleanName = glbFile.name.replace(/\.[^/.]+$/, '');
              callbacksRef.current.onRelicSaved?.(
                slotId,
                `${cleanName} (.GLB)`,
                saved
              );
            },
            () => {
              callbacksRef.current.onModelLoadStateChange?.(false);
            }
          );
          return;
        }

        if (objFile) {
          const objText = await objFile.text();
          const blobUrlByBasename = new Map<string, string>();
          let fallbackBlobUrl: string | null = null;

          for (const imgFile of imageFiles) {
            const bUrl = URL.createObjectURL(imgFile);
            const base = imgFile.name.split(/[/\\]/).pop()!.toLowerCase();
            blobUrlByBasename.set(base, bUrl);
            if (!fallbackBlobUrl) fallbackBlobUrl = bUrl;
          }

          let loadedPrimaryTexture: THREE.Texture | null = null;
          if (fallbackBlobUrl) {
            loadedPrimaryTexture = await new Promise<THREE.Texture | null>(
              (resolve) => {
                texLoader.load(
                  fallbackBlobUrl!,
                  (tex) => {
                    tex.colorSpace = THREE.SRGBColorSpace;
                    tex.anisotropy = maxAnisotropy;
                    tex.needsUpdate = true;
                    resolve(tex);
                  },
                  undefined,
                  () => resolve(null)
                );
              }
            );
          }

          const manager = new THREE.LoadingManager();
          manager.setURLModifier((url) => {
            const base = url.split(/[/\\]/).pop()?.toLowerCase() || '';
            if (blobUrlByBasename.has(base)) {
              return blobUrlByBasename.get(base)!;
            }
            return fallbackBlobUrl || url;
          });

          const objLoader = new OBJLoader(manager);
          if (mtlFile) {
            const mtlText = await mtlFile.text();
            const mtlLoader = new MTLLoader(manager);
            const materials = mtlLoader.parse(mtlText, '');
            materials.preload();
            objLoader.setMaterials(materials);
          }

          const parsedGroup = objLoader.parse(objText);
          parsedGroup.traverse((child) => {
            if (!(child as THREE.Mesh).isMesh) return;
            const mesh = child as THREE.Mesh;
            if (mesh.geometry && !mesh.geometry.attributes.normal) {
              mesh.geometry.computeVertexNormals();
            }
            const upgradeMat = (m: THREE.Material) => {
              const existingMap = (m as THREE.MeshStandardMaterial).map;
              const finalMap = existingMap || loadedPrimaryTexture || null;
              if (finalMap) {
                finalMap.colorSpace = THREE.SRGBColorSpace;
                finalMap.anisotropy = maxAnisotropy;
                finalMap.needsUpdate = true;
              }
              return new THREE.MeshStandardMaterial({
                name: m.name || 'RelicMaterial',
                color: finalMap ? 0xffffff : 0xd6c7b2,
                map: finalMap,
                roughness: 0.62,
                metalness: 0.08,
              });
            };
            if (Array.isArray(mesh.material)) {
              mesh.material = mesh.material.map(upgradeMat);
            } else if (mesh.material) {
              mesh.material = upgradeMat(mesh.material);
            }
          });

          const exportClone = parsedGroup.clone(true);
          const entry = buildNormalizedEntry(
            parsedGroup,
            [],
            spec.scaleMultiplier,
            spec.initialRotation,
            slotId
          );
          glbCache.set(spec.modelUrl, entry);
          if (stateRef.current.activeStudioModelId === slotId) {
            mountCachedEntry(entry, spec.initialRotation);
          }
          callbacksRef.current.onModelLoadStateChange?.(false);

          const cleanName = objFile.name.replace(/\.[^/.]+$/, '');
          const exporter = new GLTFExporter();
          exporter.parse(
            exportClone,
            async (result) => {
              if (result instanceof ArrayBuffer) {
                const saved = await persistGlbBufferToServer(result);
                callbacksRef.current.onRelicSaved?.(
                  slotId,
                  `${cleanName} (.OBJ 实测文物)`,
                  saved
                );
              } else {
                callbacksRef.current.onRelicSaved?.(
                  slotId,
                  `${cleanName} (.OBJ 实测文物)`,
                  false
                );
              }
            },
            () => {
              callbacksRef.current.onRelicSaved?.(
                slotId,
                `${cleanName} (.OBJ 实测文物)`,
                false
              );
            },
            { binary: true }
          );
        } else {
          callbacksRef.current.onModelLoadStateChange?.(false);
        }
      } catch {
        callbacksRef.current.onModelLoadStateChange?.(false);
      }
    };

    loadStudioModelFnRef.current = loadStudioModel;
    uploadRelicFilesFnRef.current = handleUploadRelicFiles;
    loadStudioModel(stateRef.current.activeStudioModelId);

    // Preload all 6 studio models across the 3 exhibition halls so switching is instantaneous
    const preloadTimer = window.setTimeout(() => {
      const priorityIds: StudioModelId[] = [
        'dragon-relic',
        'lantern-relic',
        'ion-drive',
        'retro-laptop',
        'dslr-camera',
        'iphone-real',
      ];
      priorityIds.forEach((id) => {
        const s = allArtifacts.find((a) => a.id === id);
        if (s) fetchAndCacheModel(s);
      });
    }, 150);

    renderer.compile(scene, camera);

    // 5. Pointer Drag & Click Raycasting
    const raycaster = new THREE.Raycaster();
    let isDragging = false;
    let prevPointerX = 0;
    let prevPointerY = 0;
    let pointerDownX = 0;
    let pointerDownY = 0;
    let lastHoverCheck = 0;

    const handlePointerDown = (e: PointerEvent) => {
      isDragging = true;
      prevPointerX = e.clientX;
      prevPointerY = e.clientY;
      pointerDownX = e.clientX;
      pointerDownY = e.clientY;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (isDragging) {
        const dx = e.clientX - prevPointerX;
        const dy = e.clientY - prevPointerY;
        prevPointerX = e.clientX;
        prevPointerY = e.clientY;
        stateRef.current.userRotY += dx * 0.008;
        stateRef.current.userRotX = THREE.MathUtils.clamp(
          stateRef.current.userRotX + dy * 0.006,
          -0.75,
          0.75
        );
        return;
      }

      const now = performance.now();
      if (now - lastHoverCheck < 50) return;
      lastHoverCheck = now;

      if (stateRef.current.worldMode === 'intro') {
        _mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
        _mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
        raycaster.setFromCamera(_mouse, camera);

        const hits = raycaster.intersectObjects(planetClickMeshes, false);
        document.body.style.cursor = hits.length > 0 ? 'pointer' : 'grab';
      } else if (stateRef.current.focusedPlanetId === 'awards') {
        document.body.style.cursor = 'default';
      } else {
        document.body.style.cursor = 'grab';
      }
    };

    const handlePointerUp = (e: PointerEvent) => {
      isDragging = false;
      const moveDist = Math.hypot(
        e.clientX - pointerDownX,
        e.clientY - pointerDownY
      );
      if (moveDist > 6) return;

      _mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      _mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
      raycaster.setFromCamera(_mouse, camera);

      if (stateRef.current.worldMode === 'intro') {
        const planetHits = raycaster.intersectObjects(planetClickMeshes, false);
        if (planetHits.length > 0) {
          const pid = planetHits[0].object.userData.planetId as PlanetId;
          if (pid) {
            callbacksRef.current.onEnterWhiteSpace(pid);
          }
        }
      }
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // 6. Main Animation Loop
    const clock = new THREE.Clock();
    let animFrameId = 0;
    let lastCrtRedraw = 0;

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();
      const st = stateRef.current;

      if (activeMixer) {
        activeMixer.update(dt);
      }

      st.warpBoost = THREE.MathUtils.damp(st.warpBoost, 0, 3.2, dt);
      const targetWhite = st.worldMode === 'white-space' ? 1.0 : 0.0;
      st.whiteBlend = THREE.MathUtils.damp(st.whiteBlend, targetWhite, 5.5, dt);

      _lerpBgColor.copy(_darkBgColor).lerp(_whiteStudioColor, st.whiteBlend);
      (scene.background as THREE.Color).copy(_lerpBgColor);
      sceneFog.color.copy(_lerpBgColor);
      sceneFog.density = THREE.MathUtils.lerp(0.012, 0.004, st.whiteBlend);

      const isStaticGallery =
        st.worldMode === 'white-space' && st.focusedPlanetId === 'awards';

      cosmicIntroGroup.visible = st.whiteBlend < 0.85;
      whiteStudioGroup.visible = st.whiteBlend > 0.15 && !isStaticGallery;

      const targetFov = 42 + st.warpBoost * 24;
      if (Math.abs(camera.fov - targetFov) > 0.05) {
        camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 6, dt);
        camera.updateProjectionMatrix();
      }

      if (st.worldMode === 'intro') {
        const stretchZ = 1 + st.warpBoost * 18;
        for (let i = 0; i < starCount; i++) {
          let sz = starCoords[i * 3 + 2] + elapsed * (1.5 + st.warpBoost * 24);
          sz = ((sz + 95) % 115) - 95;
          _dummy.position.set(starCoords[i * 3], starCoords[i * 3 + 1], sz);
          _dummy.scale.set(1, 1, stretchZ);
          _dummy.updateMatrix();
          starInstanced.setMatrixAt(i, _dummy.matrix);
        }
        starInstanced.instanceMatrix.needsUpdate = true;

        planetGroupsMap.forEach((grp) => {
          grp.rotation.y = elapsed * 0.12 + st.userRotY * 0.5;
        });

        const planet =
          PLANETS.find((p) => p.id === st.focusedPlanetId) || PLANETS[0];
        const [px, py, pz] = planet.position;
        _targetCamPos.set(px, py + 0.12, pz + 9.2);
        _targetLookAt.set(px, py - 0.28, pz);
      } else {
        _targetCamPos.set(0, 0.2, 5.2);
        _targetLookAt.set(0, 0, 0);

        // ZERO auto-rotation in the exhibition halls!
        // Models rotate ONLY when the user drags with the mouse or scrolls the wheel.
        centerModelHolder.rotation.y =
          st.scrollProgress * Math.PI * 2 + st.userRotY;
        centerModelHolder.rotation.x = st.userRotX;

        if (elapsed - lastCrtRedraw > 0.06) {
          lastCrtRedraw = elapsed;
          if (
            st.activeStudioModelId === 'all-in-one-mac' ||
            st.activeStudioModelId === 'retro-laptop'
          ) {
            drawRetroMacTerminalCanvas(
              crtCanvas,
              st.macViewIndex,
              st.reflexArchIndex,
              st.slicingEnabled,
              elapsed
            );
            crtTexture.needsUpdate = true;
          } else if (st.activeStudioModelId === 'dslr-camera') {
            drawSonyCameraLcdCanvas(cameraLcdCanvas, elapsed);
            cameraLcdTexture.needsUpdate = true;
          } else if (st.activeStudioModelId === 'iphone-real') {
            drawSmartphoneScreenCanvas(
              phoneCanvas,
              st.phonePresetIndex,
              st.customPhoneImage,
              elapsed
            );
            phoneTexture.needsUpdate = true;
          }
        }
      }

      camera.position.x = THREE.MathUtils.damp(
        camera.position.x,
        _targetCamPos.x,
        4.8,
        dt
      );
      camera.position.y = THREE.MathUtils.damp(
        camera.position.y,
        _targetCamPos.y,
        4.8,
        dt
      );
      camera.position.z = THREE.MathUtils.damp(
        camera.position.z,
        _targetCamPos.z,
        4.8,
        dt
      );

      _currentLookAt.x = THREE.MathUtils.damp(
        _currentLookAt.x,
        _targetLookAt.x,
        5.5,
        dt
      );
      _currentLookAt.y = THREE.MathUtils.damp(
        _currentLookAt.y,
        _targetLookAt.y,
        5.5,
        dt
      );
      _currentLookAt.z = THREE.MathUtils.damp(
        _currentLookAt.z,
        _targetLookAt.z,
        5.5,
        dt
      );
      camera.lookAt(_currentLookAt);

      renderer.render(scene, camera);
    };

    drawRetroMacTerminalCanvas(crtCanvas, 0, 0, true, 0);
    crtTexture.needsUpdate = true;
    drawSonyCameraLcdCanvas(cameraLcdCanvas, 0);
    cameraLcdTexture.needsUpdate = true;
    drawSmartphoneScreenCanvas(phoneCanvas, 0, null, 0);
    phoneTexture.needsUpdate = true;

    animFrameId = requestAnimationFrame(animate);

    return () => {
      window.clearTimeout(preloadTimer);
      cancelAnimationFrame(animFrameId);
      domElem.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('resize', handleResize);
      dracoLoader.dispose();
      renderer.dispose();
      if (domElem.parentNode === container) {
        container.removeChild(domElem);
      }
    };
  }, []);

  return (
    <div
      ref={canvasMountRef}
      className="fixed inset-0 w-full h-full z-0"
      aria-label="Three.js Dual-World 3D Stage"
    />
  );
};
